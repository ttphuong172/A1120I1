package _03_method;

public class Test {
    public static void main(String[] args) {

    }
}
